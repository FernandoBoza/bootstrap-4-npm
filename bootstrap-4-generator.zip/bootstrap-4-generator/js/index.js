'use strict';

/*****************************************
 * Place here your custom javascript code
 **************************************/

// Enable Bootstrap 4 Tooltips
$('[data-toggle="tooltip"]').tooltip()

